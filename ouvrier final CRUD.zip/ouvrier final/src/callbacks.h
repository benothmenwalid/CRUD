#include <gtk/gtk.h>


void
on_retour_vers_menu_ouvrier_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_ajouter_ouvrier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_ouvrier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_ouvrier_row_activated     (GtkTreeView     *treeview1_ouvrier,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_ouvrier_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_ouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_ouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_chercher_ouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_ouvriers_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_ouvriers_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercher_ouvrier_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu1_ouvrier_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_ouvrier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu2_ouvrier_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_ouvrier_clicked           	(GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu3_ouvrier_clicked        	(GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_menu4_ouvrier_clicked       	(GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_confirmer_ouvrier_clicked  	(GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modif_chercher_ouvrier_clicked      	(GtkWidget       *objet,
                                        gpointer         user_data);

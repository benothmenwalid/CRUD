#include <gtk/gtk.h>
#include <string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "ouvrier.h"

void
on_retour_menu3_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_retour_vers_menu_ouvrier_clicked            (GtkWidget       *objet,
                                        	gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_ajout_ouvrier;

	fenetre_ajout_ouvrier=lookup_widget(objet,"fenetre_ajout_ouvrier");
	

	gtk_widget_destroy(fenetre_ajout_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}
                           
void
on_ajouter_ouvrier_clicked                     (GtkWidget       *objet,
                                       	 	gpointer         user_data)
{
ouvrier o;

GtkWidget *input1, *input2, *input3, *input4, *input5, *input6;
GtkWidget *fenetre_ajout_ouvrier;

fenetre_ajout_ouvrier=lookup_widget(objet,"fenetre_ajout_ouvrier");

input1=lookup_widget(objet,"nom"); 
input2=lookup_widget(objet,"numero");
input3=lookup_widget(objet,"email");
input4=lookup_widget(objet,"cin");
input5=lookup_widget(objet,"sexe");


strcpy(o.Nomouvrier,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(o.Numeroouvrier,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(o.Emailouvrier,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(o.CINouvrier,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(o.Sexeouvrier,gtk_entry_get_text(GTK_ENTRY(input5)));


ajouter_ouvrier(o);
}



void
on_afficher_ouvrier_clicked                    (GtkWidget        *objet,
                                        	gpointer         user_data)
{
GtkWidget *fenetre_ajout_ouvrier;
GtkWidget *fenetre_afficher_ouvrier;
GtkWidget *treeview1_ouvrier;

fenetre_ajout_ouvrier=lookup_widget(objet,"fenetre_ajout_ouvrier");

gtk_widget_destroy(fenetre_ajout_ouvrier);
fenetre_afficher_ouvrier=lookup_widget(objet,"fenetre_afficher_ouvrier");
fenetre_afficher_ouvrier=create_fenetre_afficher_ouvrier();

gtk_widget_show(fenetre_afficher_ouvrier);

treeview1_ouvrier=lookup_widget(fenetre_afficher_ouvrier,"treeview1_ouvrier");

afficher_ouvrier(treeview1_ouvrier);
}


void
on_treeview1_ouvrier_row_activated             (GtkTreeView     *treeview1_ouvrier,
                                        	GtkTreePath     *path,
                                        	GtkTreeViewColumn *column,
                                        	gpointer         user_data)
{
	GtkTreeIter iter;
	gchar* nom;
	gchar* numero;
	gchar* email;
	gchar* cin;
	gchar* sexe;
	
	ouvrier o;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview1_ouvrier);

	if(gtk_tree_model_get_iter(model, &iter, path))
	{
		//obtention des valeurs de la ligne selectionnée
		gtk_tree_model_get (GTK_LIST_STORE(model),&iter, 0, &nom, 1, &numero, 2, &email, 3, &cin, 4, &sexe,-1);
		//copie des valeurs dans la variable o de type ouvrier pour passer a la fonction de suppression 
		strcpy(o.Nomouvrier,nom);
		strcpy(o.Numeroouvrier,numero);
		strcpy(o.Emailouvrier,email);
		strcpy(o.CINouvrier,cin);
		strcpy(o.Sexeouvrier,sexe);
		
		//appel de la fonction de suppression
		supprimer_ouvrier(o);
		//mise a jour de l'affichage de la treeview
		afficher_ouvrier(treeview1_ouvrier);
	}
}



void
on_retour_ouvrier_clicked                      (GtkWidget       *objet,
                                        	gpointer         user_data)
{
	GtkWidget *menu_ouvriers, *fenetre_afficher_ouvrier;

	fenetre_afficher_ouvrier=lookup_widget(objet,"fenetre_afficher_ouvrier");
	

	gtk_widget_destroy(fenetre_afficher_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}



void
on_afficher_ouvriers_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_ouvriers;
GtkWidget *fenetre_afficher_ouvrier;
GtkWidget *treeview1_ouvrier;

menu_ouvriers=lookup_widget(objet,"menu_ouvriers");
gtk_widget_destroy(menu_ouvriers);

fenetre_afficher_ouvrier=lookup_widget(objet,"fenetre_afficher_ouvrier");
fenetre_afficher_ouvrier=create_fenetre_afficher_ouvrier();

gtk_widget_show(fenetre_afficher_ouvrier);

treeview1_ouvrier=lookup_widget(fenetre_afficher_ouvrier,"treeview1_ouvrier");

afficher_ouvrier(treeview1_ouvrier);
}

void
on_ajouter_ouvriers_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_ajout_ouvrier;

	menu_ouvriers=lookup_widget(objet,"menu_ouvriers");
	

	gtk_widget_destroy(menu_ouvriers);
	fenetre_ajout_ouvrier=create_fenetre_ajout_ouvrier();
	gtk_widget_show(fenetre_ajout_ouvrier);
}

void
on_chercher_ouvriers_clicked             (GtkWidget       *objet,
                                          gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_rechercher_ouvrier;

	menu_ouvriers=lookup_widget(objet,"menu_ouvriers");
	

	gtk_widget_destroy(menu_ouvriers);
	fenetre_rechercher_ouvrier=create_fenetre_rechercher_ouvrier();
	gtk_widget_show(fenetre_rechercher_ouvrier);
}

void
on_supprimer_ouvriers_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_supprimer_ouvrier;

	menu_ouvriers=lookup_widget(objet,"menu_ouvriers");
	

	gtk_widget_destroy(menu_ouvriers);
	fenetre_supprimer_ouvrier=create_fenetre_supprimer_ouvrier();
	gtk_widget_show(fenetre_supprimer_ouvrier);
}

void
on_modifier_ouvriers_clicked             (GtkWidget       *objet,
                                         gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_modifier_ouvrier;

	menu_ouvriers=lookup_widget(objet,"menu_ouvriers");
	

	gtk_widget_destroy(menu_ouvriers);
	fenetre_modifier_ouvrier=create_fenetre_modifier_ouvrier();
	gtk_widget_show(fenetre_modifier_ouvrier);

}

void
on_rechercher_ouvrier_clicked                  (GtkWidget       *objet,
                                        	gpointer         user_data)
{
GtkWidget *cin,*sortie;
char Cin[20];
FILE *f=NULL;
	char chnom[20],chnumero[20],chemail[20];
	char chcin[20],chsexe[20];
int trouv=-1;


cin = lookup_widget (objet, "rech_id_ouvrier");
strcpy(Cin, gtk_entry_get_text(GTK_ENTRY(cin)));


f=fopen("ouvriers.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chnom,chnumero,chemail,chcin,chsexe)!=EOF)
{

if (strcmp(chcin,Cin)==0)
{strcat(chnom," ");
strcat(chnom,chcin);
strcat(chnom," ");
strcat(chnom,chnumero);
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),chnom);
trouv=1;
}
}
if (trouv!=1)
{
sortie = lookup_widget(objet, "label19");
gtk_label_set_text(GTK_LABEL(sortie),"Cin n'existe pas");
}
}
}

void
on_retour_menu1_ouvrier_clicked                (GtkWidget       *objet,
                                        	gpointer         user_data)
{
GtkWidget *menu_ouvriers, *fenetre_rechercher_ouvrier;

	fenetre_rechercher_ouvrier=lookup_widget(objet,"fenetre_rechercher_ouvrier");
	

	gtk_widget_destroy(fenetre_rechercher_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}

void
on_supprimer_ouvrier_clicked                   (GtkWidget       *objet,
                                        	gpointer         user_data)
{
GtkWidget *cin,*sortie;
char Cin[20];

int trouv;
cin = lookup_widget (objet, "supp_id_ouvrier");

strcpy(Cin, gtk_entry_get_text(GTK_ENTRY(cin)));
trouv=Chercher_ouvrier (Cin);

if (trouv==1)
{
Supprimer_ouvrier(Cin);
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"ouvrier supprimé avec succée!");
//printf("\n ouvrier supprimer avec succée!");
}
else 
{
sortie = lookup_widget(objet, "label23");
gtk_label_set_text(GTK_LABEL(sortie),"Cin introuvable!");

}
}

void
on_retour_menu2_ouvrier_clicked                (GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *fenetre_supprimer_ouvrier, *menu_ouvriers;

	fenetre_supprimer_ouvrier=lookup_widget(objet,"fenetre_supprimer_ouvrier");
	

	gtk_widget_destroy(fenetre_supprimer_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}

void
on_modifier_ouvrier_clicked            		(GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *cin,*sortie;
GtkWidget *modifier_ouvrier, *modification_ouvrier;
char Cin[20];

int trouv;
cin = lookup_widget (objet, "modif_id_ouvrier");

strcpy(Cin, gtk_entry_get_text(GTK_ENTRY(cin)));
trouv=Chercher_ouvrier (Cin);

if (trouv==1)
{
sortie = lookup_widget(objet, "label27");
gtk_label_set_text(GTK_LABEL(sortie),"ouvrier trouvé!");

modifier_ouvrier=lookup_widget(objet,"modifier_ouvrier");
	

	//gtk_widget_destroy(modifier_ouvrier);
	modification_ouvrier=create_modification_ouvrier();
	gtk_widget_show(modification_ouvrier);
}
else 
{
sortie = lookup_widget(objet, "label27");
gtk_label_set_text(GTK_LABEL(sortie),"Cin introuvable!");

}
}


void
on_retour_menu3_ouvrier_clicked                (GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *fenetre_modifier_ouvrier, *menu_ouvriers;

	fenetre_modifier_ouvrier=lookup_widget(objet,"fenetre_modifier_ouvrier");
	

	gtk_widget_destroy(fenetre_modifier_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}



void
on_retour_menu4_ouvrier_clicked        		(GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *modification_ouvrier, *menu_ouvriers;

	modification_ouvrier=lookup_widget(objet,"modification_ouvrier");
	

	gtk_widget_destroy(modification_ouvrier);
	menu_ouvriers=create_menu_ouvriers();
	gtk_widget_show(menu_ouvriers);
}


void
on_modifier_confirmer_ouvrier_clicked  		(GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *cin;
GtkWidget *input1, *input2, *input3, *input4, *input5;

	char chnom[20],chnumero[20],chemail[20],Cin[20];
	char chcin[20],chsexe[20];
FILE *f=NULL;
FILE *p=NULL;


cin = lookup_widget (objet, "modif2_cin_ouvrier");
strcpy(Cin, gtk_entry_get_text(GTK_ENTRY(cin)));

f=fopen("ouvriers.txt","r");
p=fopen("temp.txt","w");
if(f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s \n",chnom,chnumero,chemail,chcin,chsexe)!=EOF)
{
if (strcmp(chcin,Cin)==0)
{
input1=lookup_widget(objet,"nnom"); 
input2=lookup_widget(objet,"nnumero");
input3=lookup_widget(objet,"nemail");
input4=lookup_widget(objet,"ncin");
input5=lookup_widget(objet,"nsexe");


strcpy(chnom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(chnumero,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(chemail,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(chcin,gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(chsexe,gtk_entry_get_text(GTK_ENTRY(input5)));

fprintf(p,"%s %s %s %s %s \n",chnom,chnumero,chemail,chcin,chsexe);
}
else
fprintf(p,"%s %s %s %s %s \n",chnom,chnumero,chemail,chcin,chsexe);
}
fclose(f);
fclose(p);
}
remove("ouvriers.txt");
rename("temp.txt","ouvriers.txt");

}


void
on_modif_chercher_ouvrier_clicked      		(GtkWidget       *objet,
                                       		 gpointer         user_data)
{
GtkWidget *cin,*sortie;
GtkWidget *modifier_ouvrier, *modification_ouvrier;
char Cin[20];

int trouv;
cin = lookup_widget (objet, "modif2_cin_ouvrier");

strcpy(Cin, gtk_entry_get_text(GTK_ENTRY(cin)));
trouv=Chercher_ouvrier (Cin);

if (trouv==1)
{
sortie = lookup_widget(objet, "label29");
gtk_label_set_text(GTK_LABEL(sortie),"ouvrier trouvé!");

}
else 
{
sortie = lookup_widget(objet, "label29");
gtk_label_set_text(GTK_LABEL(sortie),"Cin introuvable!");

}
}

